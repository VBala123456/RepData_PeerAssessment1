<hr />

<p>title: "Reproducible Research: Peer Assessment 1"
author: "Narmatha S"
date: "2025-07-18"</p>

<h2>output: html_document</h2>

<p>```{r setup, include=FALSE}
knitr::opts_chunk$set(echo = TRUE)
library(dplyr)
library(ggplot2)
library(lattice)</p>

<pre><code>
## Loading and preprocessing the data

```{r load-data}
activity &lt;- read.csv("activity.csv")
activity$date &lt;- as.Date(activity$date)
</code></pre>

<h2>What is mean total number of steps taken per day?</h2>

<p>```{r total-steps}
total<em>steps &lt;- activity %&gt;%
  group</em>by(date) %&gt;%
  summarise(total = sum(steps, na.rm = TRUE))
hist(total<em>steps$total, main = "Total Steps per Day", xlab = "Steps", col = "blue")
mean(total</em>steps$total, na.rm = TRUE)
median(total_steps$total, na.rm = TRUE)</p>

<pre><code>
## What is the average daily activity pattern?

```{r avg-pattern}
interval_avg &lt;- activity %&gt;%
  group_by(interval) %&gt;%
  summarise(mean_steps = mean(steps, na.rm = TRUE))
plot(interval_avg$interval, interval_avg$mean_steps, type = "l", col = "red",
     main = "Average Daily Activity Pattern", xlab = "5-minute Interval", ylab = "Average Steps")
interval_avg[which.max(interval_avg$mean_steps), ]
</code></pre>

<h2>Imputing missing values</h2>

<p>```{r impute}
missing<em>vals &lt;- sum(is.na(activity$steps))
interval</em>means &lt;- interval<em>avg$mean</em>steps[match(activity$interval, interval<em>avg$interval)]
activity</em>imputed &lt;- activity
activity<em>imputed$steps[is.na(activity</em>imputed$steps)] &lt;- interval<em>means[is.na(activity$steps)]
total</em>steps<em>imputed &lt;- activity</em>imputed %&gt;%
  group<em>by(date) %&gt;%
  summarise(total = sum(steps))
hist(total</em>steps<em>imputed$total, main = "Total Steps per Day (Imputed)", col = "green")
mean(total</em>steps<em>imputed$total)
median(total</em>steps_imputed$total)</p>

<pre><code>
## Are there differences in activity patterns between weekdays and weekends?

```{r weekday-vs-weekend}
activity_imputed$day &lt;- ifelse(weekdays(activity_imputed$date) %in% c("Saturday", "Sunday"), "weekend", "weekday")
activity_imputed$day &lt;- factor(activity_imputed$day)
avg_steps_day &lt;- activity_imputed %&gt;%
  group_by(interval, day) %&gt;%
  summarise(mean_steps = mean(steps))
xyplot(mean_steps ~ interval | day, data = avg_steps_day, type = "l", layout = c(1, 2))
</code></pre>
